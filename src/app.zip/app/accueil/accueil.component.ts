import { Component } from '@angular/core';

@Component({
  selector: 'inter-accueil',
  templateUrl: './accueil.component.html',
  styleUrls: ['./accueil.component.css']
})
export class AccueilComponent {

}
